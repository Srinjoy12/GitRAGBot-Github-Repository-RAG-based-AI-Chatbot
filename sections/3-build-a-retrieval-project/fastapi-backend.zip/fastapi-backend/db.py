from supabase import create_client
import os
from dotenv import load_dotenv

load_dotenv()
supabase = create_client(os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_KEY"))

def store_repo_metadata(name: str, url: str, description: str, language: str):
    supabase.table("repositories").insert({
        "name": name,
        "url": url,
        "description": description,
        "language": language,
    }).execute()

def get_repo_by_url(repo_url: str):
    res = supabase.table("repositories").select("*").eq("url", repo_url).execute()
    if not res.data:
        raise Exception("Repository not found in database.")
    return res.data[0]
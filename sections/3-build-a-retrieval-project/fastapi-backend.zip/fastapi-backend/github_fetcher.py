import requests
import os
from dotenv import load_dotenv
from typing import List, Dict

load_dotenv('.env.local')

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
if not GITHUB_TOKEN:
    raise EnvironmentError("GITHUB_TOKEN not set in .env.local")

HEADERS = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}


def fetch_repo_data(repo_url: str) -> List[Dict[str, str]]:
    """
    Fetches top-level files from a GitHub repository (public or private),
    returns a list of {name, content} dictionaries.
    """
    if not repo_url.startswith("https://github.com/"):
        raise ValueError("Invalid GitHub URL format")

    # Extract owner and repo from URL
    owner, repo = repo_url.replace('https://github.com/', '').split('/')
    
    # Fetch repository contents
    api_url = f'https://api.github.com/repos/{owner}/{repo}/contents'
    response = requests.get(api_url, headers=HEADERS)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repository data: {response.text}")

    contents = response.json()
    files = []

    for file in contents:
        if file["type"] == "file" and file["name"].endswith((".md", ".py", ".js", ".ts", ".json", ".txt")):
            download_url = file.get("download_url")
            if not download_url:
                continue
            try:
                content_res = requests.get(download_url, headers=HEADERS)
                content_res.raise_for_status()
                files.append({
                    "name": file["name"],
                    "content": content_res.text
                })
            except Exception as e:
                print(f"Skipping file {file['name']} — error fetching content: {str(e)}")
    
    return files

import os
import openai
import weaviate
from dotenv import load_dotenv
from typing import List, Dict
from weaviate.connect import ConnectionParams
from weaviate.auth import AuthApiKey

load_dotenv('.env.local')
openai.api_key = os.getenv("OPENAI_API_KEY")

client = weaviate.WeaviateClient(
    connection_params=ConnectionParams.from_url(
        url=os.getenv("WEAVIATE_URL"),
        grpc_port=50051  # Default gRPC port for Weaviate
    ),
    auth_client_secret=AuthApiKey(os.getenv("WEAVIATE_API_KEY"))
)

# Ensure schema
def setup_schema():
    class_obj = {
        "class": "RepoChunk",
        "vectorizer": "none",
        "properties": [
            {"name": "repo_url", "dataType": ["string"]},
            {"name": "content", "dataType": ["text"]},
        ]
    }
    try:
        client.collections.get("RepoChunk")
    except weaviate.exceptions.UnexpectedStatusCodeException:
        client.collections.create(class_obj)

setup_schema()

def process_and_store_data(repo_url: str, files: list):
    collection = client.collections.get("RepoChunk")
    for file in files:
        content = file["content"]
        chunks = [content[i:i+1000] for i in range(0, len(content), 1000)]
        for chunk in chunks:
            emb = openai.Embedding.create(input=chunk, model="text-embedding-ada-002")["data"][0]["embedding"]
            collection.data.insert({
                "repo_url": repo_url,
                "content": chunk
            }, vector=emb)

def query_rag(query: str, repo_url: str):
    collection = client.collections.get("RepoChunk")
    query_emb = openai.Embedding.create(input=query, model="text-embedding-ada-002")["data"][0]["embedding"]
    res = collection.query.near_vector(
        vector=query_emb,
        limit=3,
        filters={
            "path": ["repo_url"],
            "operator": "Equal",
            "valueString": repo_url
        }
    ).do()
    context = "\n\n".join([x.properties["content"] for x in res.objects])
    answer = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Answer based ONLY on the repository content."},
            {"role": "user", "content": f"Context:\n{context}\n\nQuery: {query}"},
        ]
    )
    return answer["choices"][0]["message"]["content"]
